abstract class IModelWithId {
  final String id;

  IModelWithId({
    required this.id,
  });
}
