package com.example.m1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
